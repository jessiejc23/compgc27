import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from keras.models import Sequential
from keras.layers import LSTM, Dense, Dropout
import keras
from keras.callbacks import EarlyStopping


mfcc_data = np.load("mfccs_sample.npy")
labels = np.load("labels_sample.npy")




encode = LabelEncoder()
y = encode.fit_transform(labels)
num_class = 8


X_train0, X_test0, y_train, y_test = train_test_split(mfcc_data,y, test_size=0.15)

y_train = keras.utils.to_categorical(y_train, num_class)
y_test = keras.utils.to_categorical(y_test, num_class)




def _data_reshaping(X_tr, X_va):
    _,dim,win_len = X_tr.shape
    X_tr = np.swapaxes(X_tr,1,2)
    X_va = np.swapaxes(X_va,1,2)

    X_tr = np.reshape(X_tr,(-1,win_len,dim))
    X_va = np.reshape(X_va, (-1,win_len,dim))
    
    return X_tr,X_va



X_train,X_test = _data_reshaping(X_train0,X_test0)
_,win_len,dim = X_train.shape



#######hyper-parameters ###############################3


batch_size = 30


num_hidden_lstm1 = 64
num_hidden_lstm2 = 128
num_hidden_lstm3 = 128

nb_epoch = 3
##########################################




#model ConvLSTM


print('building the model ... ')

model = Sequential()


model.add(LSTM(num_hidden_lstm1, 
               input_shape=(win_len,dim), 
               return_sequences=True))

model.add(Dropout(0.25))


model.add(LSTM(num_hidden_lstm2, 
               input_shape=(win_len,dim), 
               return_sequences=True))


model.add(LSTM(num_hidden_lstm1, return_sequences=False))

model.add(Dropout(0.25))


model.add(Dense(32,activation='relu'))
model.add(Dense(num_class, activation='softmax'))




model.summary()

model.compile(loss='categorical_crossentropy',
              optimizer='adam', metrics = ["accuracy"])

model.fit(X_train, y_train,
          batch_size=batch_size,
          epochs=nb_epoch,
          verbose=1,
          shuffle=True,
          validation_data=(X_test, y_test),
          callbacks=[EarlyStopping(monitor='val_loss', patience=5)])







from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score



y_pred = np.argmax(model.predict(X_test),axis=1)
y_true = np.argmax(y_test,axis=1)
cf_matrix = confusion_matrix(y_true, y_pred)
print(cf_matrix)
class_wise_f1 = np.round(f1_score(y_true, y_pred, average=None)*100)*0.01
print('the mean-f1 score: {:.2f}'.format(np.mean(class_wise_f1)))
tst = np.c_[y_true,y_pred]





