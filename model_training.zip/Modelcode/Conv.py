
#import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
#from sklearn.metrics import classification_report
from sklearn.preprocessing import LabelEncoder
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Dense, Dropout,Flatten
import keras
from keras.callbacks import EarlyStopping


mfcc_data = np.load("mfccs_sample.npy")

def scaling (mfcc):
    from sklearn.preprocessing import MinMaxScaler
    scaler = MinMaxScaler()
    mfcc_sd = []
    for i in range(len(mfcc)):
        tem = scaler.fit_transform(mfcc[i].T).T
        mfcc_sd.append(tem)
    mfcc_sd = np.array(mfcc_sd)
    return mfcc_sd

mfcc_sd = scaling(mfcc_data)



labels = np.load("labels_sample.npy")

encode = LabelEncoder()
y = encode.fit_transform(labels)

num_class = 8


X_train0, X_test0, y_train, y_test = train_test_split(mfcc_sd,y, test_size=0.15)

y_train = keras.utils.to_categorical(y_train, num_class)
y_test = keras.utils.to_categorical(y_test, num_class)




def _data_reshaping(X_tr, X_va):
    _,dim,win_len = X_tr.shape
        # make it into (frame_number, dimension, window_size, channel=1) for convNet
    X_tr = np.swapaxes(X_tr,1,2)
    X_va = np.swapaxes(X_va,1,2)

    X_tr = np.reshape(X_tr,(-1,dim,win_len,1))
    X_va = np.reshape(X_va, (-1,dim,win_len, 1))
    
    return X_tr,X_va



X_train,X_test = _data_reshaping(X_train0,X_test0)
_,dim,win_len,_ = X_train.shape





#######hyper-parameters ###############################3


batch_size = 20

num_feat_map_1 = 96
num_feat_map_2 = 64
num_feat_map_3 = 32


kernel_1 = (1,20)
kernel_2 = (1,10)
kernel_3 = (1,5)
 

activation_1 = 'relu'
activation_2 = 'relu'
activation_3 = 'relu'


nb_epoch = 3
##########################################




#model Conv


print('building the model ... ')

model = Sequential()


#First Set Convolution Layer
model.add(Conv2D(num_feat_map_1, kernel_size=kernel_1,
                 activation=activation_1,
                 input_shape=(dim,win_len,1),
                 padding='same'))
model.add(MaxPooling2D(pool_size=(1,2)))

model.add(Dropout(0.25))
#Sencond Set Convolution Layer
model.add(Conv2D(num_feat_map_2, kernel_size=kernel_2,
                 activation=activation_2,
                 input_shape=(dim,win_len,1),
                 padding='same'))
model.add(MaxPooling2D(pool_size=(1, 2)))
model.add(Dropout(0.25))

model.add(Conv2D(num_feat_map_3, kernel_size=kernel_3,
                 activation=activation_3,
                 input_shape=(dim,win_len,1),
                 padding='same'))
model.add(MaxPooling2D(pool_size=(1, 2)))
model.add(Dropout(0.25))

model.add(Flatten())
model.add(Dense(512, activation='relu'))
model.add(Dense(512, activation='relu'))

model.add(Dense(num_class, activation='softmax'))




model.summary()

model.compile(loss='categorical_crossentropy',
              optimizer='adam', metrics = ["accuracy"])

model.fit(X_train, y_train,
          batch_size=batch_size,
          epochs=nb_epoch,
          verbose=1,
          shuffle=True,
          validation_data=(X_test, y_test),
          callbacks=[EarlyStopping(monitor='val_loss', patience=5)])







from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score



y_pred = np.argmax(model.predict(X_test),axis=1)

y_true = np.argmax(y_test,axis=1)
cf_matrix = confusion_matrix(y_true, y_pred)
print(cf_matrix)
class_wise_f1 = np.round(f1_score(y_true, y_pred, average=None)*100)*0.01
print('the mean-f1 score: {:.2f}'.format(np.mean(class_wise_f1)))







