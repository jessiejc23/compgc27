#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 19 16:10:45 2017

@author: WayneWu
"""

import numpy as np
import pandas as pd
import librosa
import os



path = "Arabic" #Name of the folder


def make_librosa_nor_mfcc(filename):
    y_, sr_ = librosa.load(filename,offset=0.05, duration= 21)
    y_ = librosa.util.fix_length(y_,463050)
    mfccs = librosa.feature.mfcc(y_, sr_, n_mfcc=13)
    mfccs = librosa.util.normalize(mfccs, axis= 1)
    return mfccs


def generate_mfcc(path):
    Data_dir = path
    Lang = []
    for filename in os.listdir(Data_dir):
        Lang.append(filename)
    topic = Lang[0].split("1")[0]
    Lang_t = pd.DataFrame(Lang[:])
    Lang_t.to_csv("%s_list.csv"%(topic))

    test = []
    for name in(Lang):
        mfcc = make_librosa_nor_mfcc(path+"/"+name)
        test.append(mfcc)

    test_1 = np.array(test)
    np.save("%s_mfccs"%(topic),test_1)


generate_mfcc(path)

